<?php

include_once ("../LogAcesso/cln/cgt/EntradaAlunoService.class.php");

try {    
    $entradaAlunoService = new EntradaAlunoService("log/log.txt");  
    $listaEndradaAluno = $entradaAlunoService->listaEntradaAluno();

    //print_r($listaEndradaAluno); 
    
    foreach ($listaEndradaAluno as $o) {
        echo "Codigo: ".$o->codigo.", Data: ".$o->data.", Hora: ".$o->hora."<br/>";
    }
} catch (Exception $e){
    print ($e->getMessage());
}
?>