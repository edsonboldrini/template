<?php

class EntradaAluno {

    private $hora;
    private $data;
    private $codigo;

    public function __construct($data, $hora, $codigo) {
        $this->data = $data;
        $this->hora = $hora;
        $this->codigo = $codigo;
    }

    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }

    public function diaSemanaData() {
        $semana = array(0 => "Domingo", 1 => "Segunda-Feira", 2 => "Terca-Feira", 3 => "Quarta-Feira", 4 => "Quinta-Feira", 5 => "Sexta-Feira", 6 => "Sabado");
        $dia = date('W', $this->data);
        return $dia[$semana];
    }

}

?>