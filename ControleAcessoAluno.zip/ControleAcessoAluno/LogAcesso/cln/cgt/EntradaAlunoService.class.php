<?php
include_once ("../LogAcesso/cln/cdp/EntradaAluno.class.php");

class EntradaAlunoService {
    
    private $listaEntradaAluno;
    
    public function __construct($nomeArquivo) {
        $this->listaEntradaAluno = [];
        $this->lerArquivoLog($nomeArquivo);
    }

    private function lerArquivoLog($nomeArquivo) {
        
        $arquivo = fopen($nomeArquivo, "r");

        if ($arquivo !== FALSE) {
            while (!feof($arquivo)) {
                $linha = fgets($arquivo, 4096);
                $dados = explode(";", $linha);

                $data = $dados[0];
                $hora = $dados[1];
                $codigo = $dados[2];

                $entradaAluno = new EntradaAluno($data, $hora, $codigo);
                $this->listaEntradaAluno[] = $entradaAluno;
            }
            fclose($arquivo);
        } else {
           throw new Exception("Erro na leitura do arquivo de log.");
        }
         
    }
    
    public function listaEntradaAluno() {
        return $this->listaEntradaAluno;
    }
}
?>