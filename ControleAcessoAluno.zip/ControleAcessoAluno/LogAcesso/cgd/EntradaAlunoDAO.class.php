<?php

/**
 * Description of EntradaAlunoDAO
 *
 * @author PedroBook
 */
class EntradaAlunoDAO {
   
    
}
?>
