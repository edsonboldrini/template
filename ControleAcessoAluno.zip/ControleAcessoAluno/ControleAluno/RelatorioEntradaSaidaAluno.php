<?php

include_once ("../ControleAluno/cgd/AlunoDAO.class.php");

$alunoDAO = new AlunoDAO();
$aluno = $alunoDAO->getAlunoPorCodigo($codigo);

$listaEntradaAluno = $aluno->listaEntradaAluno();

foreach ($listaEntradaAluno as $entradaAluno) {// para cada log de entrada e saida do alunos
    foreach ($listaHorarios as $horario) { //para cada horario de aula 
        if ($entradaAluno->diaSemanaData() == $horario->diaSemana) { //caso horpario deja igual dia da semana
            $listaEntradaSaida = $horario->listaEntradaSaida();
            foreach ($listaEntradaSaida as $entradaSaida) { //verifica a lista de entrada e saida do horario
                if ($entradaAluno->hora > $entradaSaida->horaEntrada ||
                        $entradaAluno->hora < $entradaSaida->horaEntrada
                ) { //caso ocorrer entrada hora do horárrio
                    //enviando notificação
                    //subtrair horario de entrada 
                }

                if ($entradaAluno->hora > $entradaSaida->horaSaida ||
                        $entradaAluno->hora < $entradaSaida->horaSaida
                ) { //caso ocorrer entrada hora do horárrio
                    //enviando notificação
                    //subtrair horario de saida 
                }

                //montar relatórios conforme os horarios
            }
        }
    }
}
?>