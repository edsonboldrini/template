<?php

class Aluno {

    private $codigo;
    private $nome;
    private $matricula;
    private $listaEntradaAluno = [];
    private $endereco;
    private $listaResponsavel = [];

    function __construct($codigo, $nome, $matricula) {
        $this->codigo = $codigo;
        $this->nome = $nome;
        $this->matricula = $matricula;
    }

    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }

    public function listaEntradaAluno(){
        return $this->listaEntradaAluno;
    }
    
    public function listaResponsavel(){
        return $this->listaResponsavel;
    }
}
