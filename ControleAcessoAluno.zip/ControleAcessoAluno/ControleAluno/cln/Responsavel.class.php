<?php

class Responsavel {

    private $nome;
    private $codigo;
    private $receberNotificacao;

    function __construct($nome, $codigo, $receberNotificacao) {
        $this->nome = $nome;
        $this->codigo = $codigo;
        $this->receberNotificacao = $receberNotificacao;
    }

    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }

    public function notificar() {
        if ($this->receberNotificacao) {
            print("Enviando notificacao!\n");
            //programa envio de email/noticação celular
        }
    }

}
