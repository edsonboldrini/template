<?php
class ResponsavelContato {
    private $contato;
    private $principal;
    
    function __construct($contato, $principal) {
        $this->contato = $contato;
        $this->principal = $principal;
    }

    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }
}
