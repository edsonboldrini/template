<?php

include_once ('./Matricula.class.php');
include_once ('./Horario.class.php');

class Turma {

    private $codigo;
    private $descricao;
    private $listaAlunoMatriculado = [];
    private $listaHorario = [];

    function __construct($codigo, $descricao) {
        $this->codigo = $codigo;
        $this->descricao = $descricao;
    }

    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }

    public function addAluno($data, $matriculado, Aluno $aluno) {
        $matricula = new Matricula($data, $matriculado, $aluno);
        $this->listaAlunoMatriculado[] = $matricula;
    }

    public function addHorario(DiaSemana $diaSemana, $listaEntradaSaida) {
        $horario = new Horario($diaSemana, $listaEntradaSaida);
        $this->listaHorario[] = $horario;
    }

    public function listaHorarios() {
        return $this->listaHorario;
    }

    public function listaAlunosMatriculados() {
        return $this->listaAlunoMatriculado;
    }

}

?>