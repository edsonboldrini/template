<?php

include_once ('./EntradaSaida.class.php');

class Horario {

    private $diaSemana;
    private $listaHorarioEntradaSaida = [];

    function __construct(DiaSemana $diaSemana, $listaHorarioEntradaSaida) {
        $this->diaSemana = $diaSemana;
        $this->listaHorarioEntradaSaida = $listaHorarioEntradaSaida;
    }

    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }

    /* private function addHorario($horaEntrada, $horaSaida) {
      $this->listaHorarioEntradaSaida = new EntradaSaida($horaEntrada, $horaSaida);
      } */
}

?>