<?php
class Curso {
    private $codigo;
    private $descricao;
    
    function __construct($codigo, $descricao) {
        $this->codigo = $codigo;
        $this->descricao = $descricao;
    }
    
    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }
}
