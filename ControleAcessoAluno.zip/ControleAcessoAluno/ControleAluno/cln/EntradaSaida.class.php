<?php

class EntradaSaida {

    private $horaEntrada;
    private $horaSaida;

    function __construct($horaEntrada, $horaSaida) {
        $this->horaEntrada = $horaEntrada;
        $this->horaSaida = $horaSaida;
    }

    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }

}
