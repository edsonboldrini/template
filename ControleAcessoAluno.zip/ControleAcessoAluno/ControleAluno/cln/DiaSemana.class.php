<?php

abstract class DiaSemana {

    const Segunda = "Segunda";
    const Terca = "Terça";
    const Quarta = "Quarta";
    const Quinta = "Quinta";
    const Sexta = "Sexta";
    const Sabado = "Sabado";

}

?>