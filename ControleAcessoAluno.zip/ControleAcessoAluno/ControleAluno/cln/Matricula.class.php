<?php

class Matricula {

    private $data;
    private $matriculado;
    private $aluno;

    function __construct($data, $matriculado, Aluno $aluno) {
        $this->data = $data;
        $this->matriculado = $matriculado;
        $this->aluno = $aluno;
    }

    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }

}
