<?php
class Endereco {
    private $rua;
    private $cep;
    private $numero;
    
    function __construct($rua, $cep, $numero) {
        $this->rua = $rua;
        $this->cep = $cep;
        $this->numero = $numero;
    }
    
    public function __set($atrib, $value) {
        $this->$atrib = $value;
    }

    public function __get($atrib) {
        return $this->$atrib;
    }
}
