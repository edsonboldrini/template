<?php

include_once ("../LogALuno/cln/Turma.class.php");
include_once ("../LogALuno/cln/Aluno.class.php");
include_once ("../LogALuno/cln/EntradaSaida.class.php");
include_once ("../LogALuno/cln/DiaSemana.class.php");

/**
 * Description of TurmaDAO
 *
 * @author PedroBook
 */
class TurmaDAO {

    private $listaTurma;

    public function __construct() {
        $this->listaTurma = [];

        $this->loadDados();
    }

    public function listaTurma() {
        $this->listaTurma;
    }

    private function loadDados() {
        $turma1 = new Turma(111, "M1");
        $turma1->addAluno("11/02/2017", 1, new Aluno("11223344", "Pedro Henrique", "1111"));
        $turma1->addAluno("10/02/2017", 1, new Aluno("22334411", "Marta Elias", "2222"));
        $turma1->addAluno("13/02/2017", 1, new Aluno("22331144", "Deborah Costa", "3333"));
        $turma1->addAluno("15/02/2017", 1, new Aluno("22113344", "Eurico Costa", "4444"));

        $listaEntradaSaida = [];
        $listaEntradaSaida[] = new EntradaSaida("07:50", "11:30");
        $listaEntradaSaida[] = new EntradaSaida("12:50", "17:10");
        $turma1->addHorario(DiaSemana::Segunda, $listaEntradaSaida);

        $listaEntradaSaida = [];
        $listaEntradaSaida[] = new EntradaSaida("08:00", "17:30");
        $turma1->addHorario(DiaSemana::Terca, $listaEntradaSaida);


        $turma2 = new Turma(222, "M2");
        $turma1->addAluno("11/02/2017", 1, new Aluno("33441122", "Emanuley", "5555"));
        $turma1->addAluno("10/02/2017", 1, new Aluno("44113322", "Isabel Elias", "6666"));

        $turma3 = new Turma(333, "M3");
        $turma4 = new Turma(444, "M4");

        $this->listaTurma[] = $turma1;
        $this->listaTurma[] = $turma2;
        $this->listaTurma[] = $turma3;
        $this->listaTurma[] = $turma4;
    }

}
