<?php

/**
 * Description of Aluno
 *
 * @author PedroBook
 */
class AlunoDAO {

    private $listaAluno = [];

    public function __construct() {
        $this->loadDados();
    }

    public function listaAluno() {
        $this->listaAluno;
    }

    private function loadDados() {
        $this->listaAluno[] = new Aluno("11223344", "Pedro Henrique", "1111");
        $this->listaAluno[] = new Aluno("22334411", "Marta Elias", "2222");
    }
    
    public function getAlunoPorCodigo($codigo) {
        //programar metodo
    }

}
