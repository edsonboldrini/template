<?php

include_once ("../ControleAluno/cgd/TurmaDAO.class.php");

$turmaDAO = new TurmaDAO();
$listaTurmas = $turmaDAO->listaTurma();

foreach ($listaTurmas as $turma) {//seleciona todas as turmas
    $listaAlunosMatriculados = $turma->listaAlunosMatriculados(); //pegar todos alunos matriculados
    $listaHorarios = $turma->listaHorarios(); //pega todos horarios das aulas

    foreach ($listaAlunosMatriculados as $aluno) {
        $listaEntradaAluno = $aluno->listaEntradaAluno();

        $notificar = false;
        foreach ($listaEntradaAluno as $entradaAluno) {// para cada log de entrada e saida do alunos
            foreach ($listaHorarios as $horario) { //para cada horario de aula 
                if ($entradaAluno->diaSemanaData() == $horario->diaSemana) { //caso horpario deja igual dia da semana
                    $listaEntradaSaida = $horario->listaEntradaSaida();
                    foreach ($listaEntradaSaida as $entradaSaida) { //verifica a lista de entrada e saida do horario
                        if ($entradaAluno->hora > $entradaSaida->horaEntrada ||
                                $entradaAluno->hora < $entradaSaida->horaEntrada
                        ) { //caso ocorrer entrada hora do horário
                            //enviando notificação
                            $notificar = true;
                        }
                    }
                }
            }
        }

        if ($notificar) {
            $listaResponsavel = $aluno->listaResponsavel();
            foreach ($listaResponsavel as $responsavel) {
                $responsavel->notificar();
            }
        }
    }
}
?>